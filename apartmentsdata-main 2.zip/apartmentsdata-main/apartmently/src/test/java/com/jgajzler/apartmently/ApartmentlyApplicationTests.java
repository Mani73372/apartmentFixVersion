package com.jgajzler.apartmently;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApartmentlyApplicationTests {

	@Test
	void contextLoads() {
	}

}
