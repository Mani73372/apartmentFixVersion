package com.jgajzler.apartmently.entity.enums;

public enum UserRole {
    ADMIN,
    COMMON_USER
}
