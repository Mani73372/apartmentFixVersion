package com.jgajzler.apartmently.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Date;
import java.util.List;

@Getter
@AllArgsConstructor
public class ConversationDto {

    private  Long id;
    private  Long user1Id;
    private  Long user2Id;
    private  Date dateCreated;
    private  List<MessageDto> messages;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getUser1Id() {
		return user1Id;
	}
	public void setUser1Id(Long user1Id) {
		this.user1Id = user1Id;
	}
	public Long getUser2Id() {
		return user2Id;
	}
	public void setUser2Id(Long user2Id) {
		this.user2Id = user2Id;
	}
	public Date getDateCreated() {
		return dateCreated;
	}
	public void setDateCreated(Date dateCreated) {
		this.dateCreated = dateCreated;
	}
	public List<MessageDto> getMessages() {
		return messages;
	}
	public void setMessages(List<MessageDto> messages) {
		this.messages = messages;
	}
    
    
}
