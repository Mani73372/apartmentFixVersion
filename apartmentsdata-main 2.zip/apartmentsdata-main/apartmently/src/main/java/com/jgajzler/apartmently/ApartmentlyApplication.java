package com.jgajzler.apartmently;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApartmentlyApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApartmentlyApplication.class, args);
	}

}
