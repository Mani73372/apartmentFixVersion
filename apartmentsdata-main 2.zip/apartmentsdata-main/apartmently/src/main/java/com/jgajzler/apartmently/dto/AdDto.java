package com.jgajzler.apartmently.dto;

import com.jgajzler.apartmently.entity.AdImage;
import com.jgajzler.apartmently.entity.enums.AdType;
import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Date;
import java.util.Set;

@Getter
@AllArgsConstructor

public class AdDto {

    private  Long id;
    private  String adName;
    private  double plotSurface;
    private  int price;
    private  int numberOfBedrooms;
    private  int numberOfBathrooms;
    private  Date dateCreated;
    private  Date lastUpdated;
    private  boolean isActive;
    private  String city;
    public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getAdName() {
		return adName;
	}
	public void setAdName(String adName) {
		this.adName = adName;
	}
	public double getPlotSurface() {
		return plotSurface;
	}
	public void setPlotSurface(double plotSurface) {
		this.plotSurface = plotSurface;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getNumberOfBedrooms() {
		return numberOfBedrooms;
	}
	public void setNumberOfBedrooms(int numberOfBedrooms) {
		this.numberOfBedrooms = numberOfBedrooms;
	}
	public int getNumberOfBathrooms() {
		return numberOfBathrooms;
	}
	public void setNumberOfBathrooms(int numberOfBathrooms) {
		this.numberOfBathrooms = numberOfBathrooms;
	}
	public Date getDateCreated() {
		return dateCreated;
	}
	public void setDateCreated(Date dateCreated) {
		this.dateCreated = dateCreated;
	}
	public Date getLastUpdated() {
		return lastUpdated;
	}
	public void setLastUpdated(Date lastUpdated) {
		this.lastUpdated = lastUpdated;
	}
	public boolean isActive() {
		return isActive;
	}
	public void setActive(boolean isActive) {
		this.isActive = isActive;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public Set<AdImage> getAdImages() {
		return adImages;
	}
	public void setAdImages(Set<AdImage> adImages) {
		this.adImages = adImages;
	}
	public AdType getAdType() {
		return adType;
	}
	public void setAdType(AdType adType) {
		this.adType = adType;
	}
	private  String country;
    private  Set<AdImage> adImages;
    private  AdType adType;
}
