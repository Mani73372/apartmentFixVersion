package com.jgajzler.apartmently.entity.enums;

public enum AdType {
    SALE,
    RENT
}
