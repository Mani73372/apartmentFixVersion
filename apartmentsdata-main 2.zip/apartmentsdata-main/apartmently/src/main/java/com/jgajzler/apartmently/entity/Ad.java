package com.jgajzler.apartmently.entity;

import java.util.Date;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;
import org.hibernate.annotations.UpdateTimestamp;

//import com.jgajzler.apartmently.config.MySQLEnumType;
//import com.jgajzler.apartmently.config.PostgreSQLEnumType;
import com.jgajzler.apartmently.config.StringEnumType;
import com.jgajzler.apartmently.entity.enums.AdType;

import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "ads")
@TypeDef(name = "mysql_enum", typeClass = StringEnumType.class)
@Getter
@Setter
public class Ad {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Long id;

	@Column(name = "ad_name")
	private String adName;

	@Column(name = "description")
	private String description;

	@Column(name = "plot_surface", nullable = false)
	private double plotSurface;

	@Column(name = "price", nullable = false)
	private int price;

	@Column(name = "number_of_bedrooms", nullable = false)
	private int numberOfBedrooms;

	@Column(name = "number_of_bathrooms", nullable = false)
	private int numberOfBathrooms;

	@Column(name = "floor_number")
	private int floorNumber;

	@Column(name = "date_created")
	@CreationTimestamp
	private Date dateCreated;

	@Column(name = "last_updated")
	@UpdateTimestamp
	private Date lastUpdated;

	@Column(name = "is_active")
	private boolean isActive = true;

	// @OneToOne(cascade = CascadeType.ALL, orphanRemoval = true)
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "address_id", referencedColumnName = "id", nullable = false)
	private Address address;

	@OneToMany(cascade = CascadeType.ALL, mappedBy = "ad")
	private Set<AdImage> adImages;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "user_id", nullable = false)
	private User user;

	@ManyToMany(fetch = FetchType.LAZY)
	@JoinTable(name = "users_favorites", joinColumns = @JoinColumn(name = "ad_id"), inverseJoinColumns = @JoinColumn(name = "user_id"))
	Set<User> usersFav;

	@ManyToMany(fetch = FetchType.LAZY)
	@JoinTable(name = "permitted_users", joinColumns = @JoinColumn(name = "ad_id"), inverseJoinColumns = @JoinColumn(name = "user_id"))
	Set<User> permittedUsers;

	@Enumerated(EnumType.STRING)
	@Column(name = "ad_type", columnDefinition = "ad_type_enum", nullable = false)
	@Type(type = "mysql_enum")
	AdType adType;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getAdName() {
		return adName;
	}

	public void setAdName(String adName) {
		this.adName = adName;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public double getPlotSurface() {
		return plotSurface;
	}

	public void setPlotSurface(double plotSurface) {
		this.plotSurface = plotSurface;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public int getNumberOfBedrooms() {
		return numberOfBedrooms;
	}

	public void setNumberOfBedrooms(int numberOfBedrooms) {
		this.numberOfBedrooms = numberOfBedrooms;
	}

	public int getNumberOfBathrooms() {
		return numberOfBathrooms;
	}

	public void setNumberOfBathrooms(int numberOfBathrooms) {
		this.numberOfBathrooms = numberOfBathrooms;
	}

	public int getFloorNumber() {
		return floorNumber;
	}

	public void setFloorNumber(int floorNumber) {
		this.floorNumber = floorNumber;
	}

	public Date getDateCreated() {
		return dateCreated;
	}

	public void setDateCreated(Date dateCreated) {
		this.dateCreated = dateCreated;
	}

	public Date getLastUpdated() {
		return lastUpdated;
	}

	public void setLastUpdated(Date lastUpdated) {
		this.lastUpdated = lastUpdated;
	}

	public boolean isActive() {
		return isActive;
	}

	public void setActive(boolean isActive) {
		this.isActive = isActive;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public Set<AdImage> getAdImages() {
		return adImages;
	}

	public void setAdImages(Set<AdImage> adImages) {
		this.adImages = adImages;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public Set<User> getUsersFav() {
		return usersFav;
	}

	public void setUsersFav(Set<User> usersFav) {
		this.usersFav = usersFav;
	}

	public Set<User> getPermittedUsers() {
		return permittedUsers;
	}

	public void setPermittedUsers(Set<User> permittedUsers) {
		this.permittedUsers = permittedUsers;
	}

	public AdType getAdType() {
		return adType;
	}

	public void setAdType(AdType adType) {
		this.adType = adType;
	}

}
