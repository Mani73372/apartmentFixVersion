package com.jgajzler.apartmently.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Date;

@Getter
@AllArgsConstructor
public class MessageListDto {
    private  Long id;
    private  Long user1Id;
    private  Long user2Id;
    private  String user1Name;
    private  String user2Name;
    private  String user1Url;
    private  String user2Url;
    private  Date dateCreated;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getUser1Id() {
		return user1Id;
	}
	public void setUser1Id(Long user1Id) {
		this.user1Id = user1Id;
	}
	public Long getUser2Id() {
		return user2Id;
	}
	public void setUser2Id(Long user2Id) {
		this.user2Id = user2Id;
	}
	public String getUser1Name() {
		return user1Name;
	}
	public void setUser1Name(String user1Name) {
		this.user1Name = user1Name;
	}
	public String getUser2Name() {
		return user2Name;
	}
	public void setUser2Name(String user2Name) {
		this.user2Name = user2Name;
	}
	public String getUser1Url() {
		return user1Url;
	}
	public void setUser1Url(String user1Url) {
		this.user1Url = user1Url;
	}
	public String getUser2Url() {
		return user2Url;
	}
	public void setUser2Url(String user2Url) {
		this.user2Url = user2Url;
	}
	public Date getDateCreated() {
		return dateCreated;
	}
	public void setDateCreated(Date dateCreated) {
		this.dateCreated = dateCreated;
	}
}
