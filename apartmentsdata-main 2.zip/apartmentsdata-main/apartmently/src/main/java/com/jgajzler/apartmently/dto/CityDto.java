package com.jgajzler.apartmently.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class CityDto {

    private  String name;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}
