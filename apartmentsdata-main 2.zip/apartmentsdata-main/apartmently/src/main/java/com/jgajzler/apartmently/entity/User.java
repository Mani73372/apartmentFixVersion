package com.jgajzler.apartmently.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.jgajzler.apartmently.entity.enums.UserRole;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.Type;

import javax.persistence.*;
import java.util.Set;

@Entity
@Table(name = "users", uniqueConstraints = {
        @UniqueConstraint(name = "email_unique", columnNames = "email"),
        @UniqueConstraint(name = "username_unique", columnNames = "username"),

})
@Getter
@Setter
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "email", columnDefinition = "VARCHAR(100)", nullable = false)
    private String email;

    @Column(name = "password", columnDefinition = "VARCHAR(255)", nullable = false)
    private String password;

    @Column(name = "username", columnDefinition = "VARCHAR(50)", nullable = false)
    private String username;

    @OneToOne(mappedBy = "user")
    private UserDetails userDetails;

    @OneToMany(cascade = CascadeType.REMOVE, mappedBy = "user")
    private Set<Ad> ads;

    @ManyToMany(mappedBy = "usersFav", cascade = CascadeType.REMOVE)
    Set<Ad> favoriteAds;

    @ManyToMany(mappedBy = "permittedUsers", cascade = CascadeType.REMOVE)
    Set<Ad> permittedAds;

    @JsonIgnore
    @Enumerated(EnumType.STRING)
    @Column(name = "user_role", columnDefinition = "user_role_enum default 'COMMON_USER'")
    @Type(type = "mysql_enum")
    UserRole userRole = UserRole.COMMON_USER;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public UserDetails getUserDetails() {
		return userDetails;
	}

	public void setUserDetails(UserDetails userDetails) {
		this.userDetails = userDetails;
	}

	public Set<Ad> getAds() {
		return ads;
	}

	public void setAds(Set<Ad> ads) {
		this.ads = ads;
	}

	public Set<Ad> getFavoriteAds() {
		return favoriteAds;
	}

	public void setFavoriteAds(Set<Ad> favoriteAds) {
		this.favoriteAds = favoriteAds;
	}

	public Set<Ad> getPermittedAds() {
		return permittedAds;
	}

	public void setPermittedAds(Set<Ad> permittedAds) {
		this.permittedAds = permittedAds;
	}

	public UserRole getUserRole() {
		return userRole;
	}

	public void setUserRole(UserRole userRole) {
		this.userRole = userRole;
	}
    
    
    
}
