package com.jgajzler.apartmently.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public class AdDetailsDto {
    private  Long id;
    private  int floor;
    private  Long userId;
    private  String userName;
    private  String userPhone;
    private  String userEmail;
    private  String userImage;
    private  String description;
    private  double longitude;
    private  double latitude;
	public Long getId() {
		return id;
	}
	public int getFloor() {
		return floor;
	}
	public Long getUserId() {
		return userId;
	}
	public String getUserName() {
		return userName;
	}
	public String getUserPhone() {
		return userPhone;
	}
	public String getUserEmail() {
		return userEmail;
	}
	public String getUserImage() {
		return userImage;
	}
	public String getDescription() {
		return description;
	}
	public double getLongitude() {
		return longitude;
	}
	public double getLatitude() {
		return latitude;
	}

}
